# LiquidCrystal_I2C_Software
LiquidCrystal Arduino library for the I2C LCD displays
